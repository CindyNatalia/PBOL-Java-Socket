/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socket;
import java.net.*;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Nice
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
                Scanner sc = new Scanner(System.in);
                System.out.print("Masukkan IP Address : ");
                String ip = sc.nextLine();
                System.out.print("Masukkkan Socket Server : ");
                int socket = sc.nextInt();
                Socket sk=new Socket(ip, socket);
                BufferedReader sin=new BufferedReader(new InputStreamReader(sk.getInputStream()));
                PrintStream sout=new PrintStream(sk.getOutputStream());
                BufferedReader stdin=new BufferedReader(new InputStreamReader(System.in));
            String s;
        while (  true )
        {
            System.out.print("Client : ");
            s = stdin.readLine();
            sout.println(s);
            s = sin.readLine();
            System.out.print("Server : "+s+"\n");
     if ( s.equalsIgnoreCase("BYE") )
       break;
  }
   sk.close();
   sin.close();
   sout.close();
   stdin.close();
            } catch (Exception e) {
                System.out.println("Gagal Terhubung ke Server");
            }
       }
}
